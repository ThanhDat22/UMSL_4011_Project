import { get } from 'http';
import { Product, products } from '../model';

export const getProducts = (): Product[] => {
  return products;
}

export const getProduct = (id: number): Product | undefined => {
  return products.find(product => product.id === id);
}

type CreateProductProps = Product & {
  id: never;
}

export const createProduct = (product: CreateProductProps) => {
  const newID = new Date().valueOf();

  const newProduct = {
    ...product,
    id: newID,
  }

  products.push(newProduct);
  return newProduct;
}

export const deleteProduct = (id: number): boolean => {
  const index = products.findIndex(product => product.id === id);
  if (index === -1) {
    return false;
  }
  products.splice(index, 1);
  return true;
}


export const editProduct = (id: number, product: Product): boolean => {
  const index = products.findIndex(product => product.id === id);
  if (index === -1) {
    return false;
  }
  products[index] = { 
    ...products[index], 
    ...product };
  return true;
}