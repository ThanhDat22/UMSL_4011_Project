import e, { NextFunction, Request, Response } from "express";
import { getProduct, getProducts, createProduct, deleteProduct, editProduct } from "../services";

export const getProductController = (req: Request, res: Response, next: NextFunction) => {
    const id = Number(req.params.id);
    if (!id) {
        res.status(400).send('Invalid ID');
        next();
        return;
    }
    
    const result = getProduct(id);

    if (!result) {
        res.status(404).send('Product not found');
        next();
        return;
    }

    res.send(result).status(200);
    next();
}

export const getProductsController = (req: Request, res: Response, next: NextFunction) => {
    const result = getProducts();
    res.send(result).status(200);   
}

export const createProductController = (req: Request, res: Response, next: NextFunction) => {
    const  product = req.body;

    const result = createProduct(product);

    res.send({
        product: result,
        success: true,
        msg: ''
    });
}

export const deleteProductController = (req: Request, res: Response, next: NextFunction) => {
    const id = Number(req.params.id);
    if (!id) {
        res.status(400).send('Invalid ID');
        next();
        return;
    }
    
    const result = deleteProduct(id);

    if (result) {
        res.send('Successfully deleted product').status(200);
    } else {
        res.status(404).send('Product not found');
    }
}

export const editProductController = (req: Request, res: Response, next: NextFunction) => {
    const id = Number(req.params.id);
    const product = req.body;
    if (!id) {
        res.status(400).send('Invalid ID');
        next();
        return;
    }
    

    const result = editProduct(id, product);

    if (result) {
        res.send('Successfully edited product').status(200);
    } else {
        res.status(404).send('Product not found');
    }
}